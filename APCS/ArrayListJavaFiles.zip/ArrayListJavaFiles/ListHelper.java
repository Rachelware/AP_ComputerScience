import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


/**
 * Write a description of class ListHelper here.
 * 
 * @author Rachel Ware
 * @version 11.14.16
 */
public class ListHelper
{
    // instance variables - replace the example below with your own
    private int numOddStrings;
    private int numSame;

    /**
     * Constructor for objects of class ListHelper
     */
    public ListHelper()
    {
        // initialise instance variables
    }

    /**
     * Returns the number of Strings in rayList with odd length
     * 
     * @param  rayList    
     * @return   numStrings   number of strings in rayList
     */
    public int countOddLength (ArrayList <String> rayList)
    {
        for (String element : rayList)
        {
            if ((element.length() % 2) == 1)
            {
                numOddStrings++;
            }
        }
        return numOddStrings;
    }
    
    /**
     * Remove all Strings in rayList that start with the same first letter as firstLetter
     * 
     * @param  rayList
     * @param  firstLetter  
     * @return rayList
     */
    public void removeStrings (ArrayList <String> rayList, char firstLetter)
    {
        for (int i = 0; i < rayList.size()-1; i++)
        {
            String element = rayList.get(i);
            if ((element.charAt(0) == (firstLetter)) && element.length() > 0)
            {
                rayList.remove(rayList.get(element.indexOf(element)));
                i = i -1;
            }
        }
    }
    
    /**
     * Returns the number of times num is present in rayList
     * 
     * @param  rayList
     * @param  num
     * @return num
     */
    public int numCount (ArrayList <Integer> rayList, int num)
    {
        for (int element : rayList)
        {
            if (element == num)
            {
                numSame++;
            }
        }
        return numSame;
    }
}
