import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class ListHelperTest
{
	private ArrayList<String> testArray;
	private ListHelper helper = new ListHelper();
	
	@Before
	public void setUp() throws Exception
	{
		testArray = new ArrayList<String>();	
		testArray.add("odd");
		testArray.add("odder");
		testArray.add("even");
		testArray.add("oddalso");
		testArray.add("a");
		testArray.add("");
	}

	@After
	public void tearDown() throws Exception
	{

	}

	@Test
	public void testCountOddLength()
	{
		int result = helper.countOddLength(testArray);
		assertEquals(4, result);
	}
	
	@Test
	public void testRemove() {
		helper.removeStrings(testArray, 'o');
		assertEquals(3, testArray.size());
		
	}
	
	@Test
	public void testNumCount() {
		ArrayList<Integer> integers = new ArrayList<Integer>();
		integers.add(1);
		integers.add(12);
		integers.add(5);
		integers.add(3);
		integers.add(1);
		int integerCount = helper.numCount(integers, 1);
		assertEquals(2, integerCount);
		
	}
}
