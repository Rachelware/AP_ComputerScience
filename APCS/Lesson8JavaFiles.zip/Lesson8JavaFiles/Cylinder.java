
/**
 * Write a description of class Cylinder here.
 * 
 * @author Rachel Ware 
 * @version 1.19.17
 */
public class Cylinder
{
    // instance variables - replace the example below with your own
    private double r;
    private double h;

    /**
     * Constructor for objects of class Cylinder
     */
    public Cylinder(double r, double h)
    {
        this.r = r;
        this.h = h;
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public double cylinderVolume()
    {
        // put your code here
        return Math.PI*r*r*h;
    }
    
    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public double cylinderSurface()
    {
        // put your code here
        return (2*Math.PI*r*h) + (2*Math.PI*r*r);
    }
}
