/**
 * Write a description of class Geometry here.
 * E8.5
 * 
 * @author Rachel Ware
 * @version 1.18.17
 */
public class Geometry
{
    // instance variables - replace the example below with your own
    private int x = 0;

    /**
     * Constructor for objects of class Geometry
     */
    public double E8_6()
    {
        // initialise instance variables
        x = 0;
        return x;
    }
    
    /**
     * Volume of a cube
     * 
     * @param  h   height as a double
     * @return     the volume of the cube
     */
    public static double cubeVolume(double h)
    {
        return h*h*h;
    }
    
    /**
     * Surface Area of a Cube
     * 
     * @param  h   height as a double
     * @return     surface area of the cube
     */
    public static double cubeSurface(double h)
    {
        return h*h*6;
    }
    
    /**
     * Sphere Volume
     * 
     * @param  r   radius of the sphere
     * @return     volume of the sphere
     */
    public static double sphereVolume(double r)
    {
        return r*r*r*Math.PI*(4.0/3.0);
    }
    
    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public static double sphereSurface(double r)
    {
        return 4*Math.PI*r*r;
    }
    
    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public static double cylinderVolume(double r, double h)
    {
        return Math.PI*r*r*h;
    }
    
    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public static double cylinderSurface(double r, double h)
    {
        return (2*Math.PI*r*h) + (2*Math.PI*r*r);
    }
    
    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public static double coneVolume(double r, double h)
    {
        return Math.PI*r*r*(h/3);
    }
    
    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public static double coneSurface(double r, double h)
    {
        return Math.PI*r*(r + Math.sqrt((h*h) + (r*r)));
    }
}
