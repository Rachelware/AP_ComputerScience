import java.util.Scanner;
/**
 * Write a description of class Input here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Input
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        Input.readInt(in, "Enter a number between 5 and 20: ", "Error: number not in range", 5, 20);
        
    }
    
    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public static int readInt(Scanner in, String prompt, String error, int min, int max)
    {
        int integer = 0;
        System.out.print(prompt);
        integer = in.nextInt();
        if (integer > min && integer < max)
        {
            return integer;
        }
        else
        {
            while (integer <= min || integer >= max)
            {
                System.out.println(error);
                System.out.print(prompt);
                integer = in.nextInt();

            }
        }
        return integer;
    }
}
