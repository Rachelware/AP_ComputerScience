import java.util.Scanner;
/**
 * Write a description of class CylTester here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CylTester
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        System.out.print("Input a radius: ");
        double r = in.nextDouble();
        System.out.print("Input a height: ");
        double h = in.nextDouble();
        Cylinder cyl = new Cylinder(r,h);
        System.out.printf("Cylinder volume: %.2f\n", cyl.cylinderVolume());
        System.out.printf("Cylinder surface: %.2f\n", cyl.cylinderSurface());
    }
}
