import java.util.Scanner;
/**
 * Write a description of class GeometryTester here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GeometryTester
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        System.out.print("Input a radius: ");
        double r = in.nextDouble();
        System.out.print("Input a height: ");
        double h = in.nextDouble();
        System.out.printf("cube volume: %.2f\n", Geometry.cubeVolume(h));
        System.out.printf("cube surface area: %.2f\n", Geometry.cubeSurface(h));
        System.out.printf("sphere volume: %.2f\n", Geometry.sphereVolume(r));
        System.out.printf("sphere surface area: %.2f\n", Geometry.sphereSurface(r));
        System.out.printf("cylinder volume: %.2f\n", Geometry.cylinderVolume(r, h));
        System.out.printf("cylinder surface area: %.2f\n", Geometry.cylinderSurface(r, h));
        System.out.printf("cone volume: %.2f\n", Geometry.coneVolume(r, h));
        System.out.printf("cone surface area: %.2f\n", Geometry.coneSurface(r, h));
    }
}
