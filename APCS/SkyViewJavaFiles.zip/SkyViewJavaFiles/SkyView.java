
public class SkyView
{
    private double[][] view;
   
    public SkyView(int numRows, int numCols, double[] scanned)
    {
       int column = 0;
       int next = 0;
       view = new double[numRows][numCols];
       while (column < numCols)
       {
           for (int row = 0; row < numRows; row++)
           {
               view[row][column] = scanned[next];
               next++;
            }
           column++;
           for (int row = view.length - 1; row > 0; row --)
           {
               view[row][column] = scanned[next];
               next++;
            }
           column++; 
        }
       
                
    }

   
    public double getAverage(int startRow, int endRow, int startCol, int endCol)
    {
       double sum = 0.0;
       double count = 0.0;
       for (int i = startRow; i <= endRow; i++)
       {
           for (int j = startCol; j <= endCol; j++)
           {
               sum = sum + view[i][j];
               count++;
            }
        }
       return sum/count;
    }
}
