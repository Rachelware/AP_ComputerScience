
/**
 * Write a description of class SkyViewTester here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SkyViewTester
{
   public static void main(String[] args)
   {
       double[] array1 = {0.3, 0.7, 0.8, 0.4, 1.4, 1.1, 0.2, 0.5, 0.1, 1.6, 0.6, 0.9};
       int[] loc1 = {1, 2, 0, 1};
       double answer1 = .8;
       
       double[] array2 = {0.3, 0.7, 0.8, 0.4, 1.4, 1.1};
       int[] loc2 = {0, 1, 0, 1};
       double answer2 = .55;
       
       test(4, 3, array1, loc1, answer1);
       test(3, 2, array2, loc2, answer2);
   }
   
   public static void test(int numRows, int numCols, double[] array, int[] loc, double answer) {
       SkyView test = new SkyView(numRows, numCols, array);
       double average = test.getAverage(loc[0], loc[1], loc[2], loc[3]);
       System.out.println("Expected: " + answer);
       System.out.println("Actual: " + average);
       if(average == answer)
       {
           System.out.println("Result: passed");
       }
       else
       {
           System.out.println("Result: failed");
       }
       System.out.println();
   }
}
