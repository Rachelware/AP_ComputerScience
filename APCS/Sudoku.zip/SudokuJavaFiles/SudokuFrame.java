import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.BorderFactory;
import java.io.IOException;
import java.util.Random;
/**
 * SudokuFrame creates a Sudoku Game with a button to check whether answers are correct and another
 * button that sets the board background to white.
 * 
 * @author Rachel Ware
 * @version 5.4.17
 */
public class SudokuFrame extends JFrame implements ActionListener
{
    //sizing constants
    public static final int GRID_SIZE = 9;
    public static final int CELL_SIZE = 60;
    public static final int CANVAS_WIDTH = CELL_SIZE * GRID_SIZE;
    public static final int CANVAS_HEIGHT = CANVAS_WIDTH;
    //arrays
    public static JTextField[][] answer = new JTextField[GRID_SIZE][GRID_SIZE];
    public static JTextField[][] squares = new JTextField[GRID_SIZE][GRID_SIZE];
    private static String[][] userInput = new String[answer.length][answer[0].length];
    public static JTextField[][] correct = new JTextField[GRID_SIZE][GRID_SIZE];
    public static JTextField[][] incorrect = new JTextField[GRID_SIZE][GRID_SIZE];
    //Swing framing and buttons
    private static JFrame frame = new JFrame("Sudoku");
    private static JPanel mainPanel = new JPanel();
    private static JPanel gamePanel = new JPanel(new GridLayout(GRID_SIZE, GRID_SIZE));
    private static JPanel menuPanel = new JPanel(new GridLayout(3,1));
    private static JButton check = new JButton("Check answers");
    private static JButton reset = new JButton("reset colors");    
    
    /**
     * Constructor for objects of class SudokuFrame
     */
    public SudokuFrame()
    {

    }
    
    public static void main(String[] args)
    {
        frame.setBounds(1200,50,200,200); //sets up frame
        
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        frame.getContentPane().add(mainPanel);
        
        //Sudoku board panel
        gamePanel.setPreferredSize(new Dimension(CANVAS_WIDTH, CANVAS_WIDTH));
        mainPanel.add(gamePanel);
        
        //menu buttons panel
        menuPanel.setPreferredSize(new Dimension(CANVAS_WIDTH, 100));
        menuPanel.add(check);
        menuPanel.add(reset);
        mainPanel.add(menuPanel);
        
        //answer to current puzzle
        String[][] answerValues = PuzzleGenerator.getPuzzle();
        
        //sets visual grid to puzzle
        for (int i = 0; i < SudokuPuzzle.getGridSize(); i++)
        {
             for (int j = 0; j < SudokuPuzzle.getGridSize(); j++)
             {
                 answer[i][j] = new JTextField(answerValues[i][j]);
             }
        }
        
        //randomly selects some squares to be empty and filled squares to be uneditable
        Random randInt = new Random();
        for (int i = 0; i < SudokuPuzzle.getGridSize(); i++)
        {
            for (int j = 0; j < SudokuPuzzle.getGridSize(); j++)
            {
                //create squares
                squares[i][j] = new JTextField();
                //sets borders to separate small boxes visually
                squares[i][j].setBorder(BorderFactory.createMatteBorder(1,1,1,1,Color.BLUE));
                if ((i + 1) % 3 == 0)
                 {
                     squares[i][j].setBorder(BorderFactory.createMatteBorder(1,1,3,1,Color.BLUE));
                 }
                if ((j + 1) % 3 == 0)
                {
                    squares[i][j].setBorder(BorderFactory.createMatteBorder(1,1,1,3,Color.BLUE));
                }
                if (((j + 1) % 3 == 0) && ((i + 1) % 3 == 0))
                {
                    squares[i][j].setBorder(BorderFactory.createMatteBorder(1,1,3,3,Color.BLUE));
                }
                gamePanel.add(squares[i][j]); //add squares
                squares[i][j].setText("" + answerValues[i][j]); //labels all squares with numbers
                if ((randInt.nextInt(50) + 1) % 2 == 0) //generates random value
                {
                    squares[i][j].setEditable(false); //sets prefilled squares
                }
                else
                {
                    squares[i][j].setText(""); //sets empty squares
                }
            }
        }    
        
        //action listener for check button
        check.addActionListener(new ActionListener() 
        {
            @Override
            public void actionPerformed(ActionEvent e){
                int correctCount = 0;
                //changes color to indicate whether squares are correctly or incorrectly filled
                for (int i = 0; i < SudokuPuzzle.getGridSize(); i++)
                {
                    for (int j = 0; j < SudokuPuzzle.getGridSize(); j++)
                    {
                        userInput[i][j] = squares[i][j].getText(); //gets user input
                        if (userInput[i][j].equals(answerValues[i][j])) //if user input is correct                                                                
                        {
                            squares[i][j].setBackground(new Color(50,255,50));
                            correctCount++;
                        }
                        else //if user input is incorrect
                        {
                            squares[i][j].setBackground(new Color(255,0,0));
                        }
                    }
                }
                //Tells user they won when all squares are correct
                if (correctCount == GRID_SIZE * GRID_SIZE)
                {
                    JOptionPane.showMessageDialog(null, "You Win!");
                }
            }
        });
        
        //action listener for reset button
        reset.addActionListener(new ActionListener() 
        {
            @Override
            public void actionPerformed(ActionEvent e){
                //sets all puzzle square backgrounds to white
                for (int i = 0; i < SudokuPuzzle.getGridSize(); i++)
                {
                    for (int j = 0; j < SudokuPuzzle.getGridSize(); j++)
                    {
                        squares[i][j].setBackground(Color.WHITE);
                    }
                }
            }
        });
        
        //sets up frame
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle("Sudoku");
        frame.setVisible(true);
    }
    
    //needed for using ActionListener interface
    //not in use
    public void actionPerformed(ActionEvent event)
    {
        
    }    
}
