import java.util.Random;
/**
 * Chooses a random puzzle to pass to SudokuFrame from an array.
 * 
 * @author Rachel Ware
 * @version 5.31.17
 */
public class PuzzleGenerator
{

    /**
     * Constructor for objects of class PuzzleGenerator
     */
    public PuzzleGenerator()
    {

    }

    /**
     * Gets a random puzzle from puzzle array
     * 
     * @return     thePuzzle   2D array with all the values of a random puzzle
     */
    public static String[][] getPuzzle()
    {
        Random randInt = new Random();
        String [][][] puzzles = SudokuPuzzle.getPuzzleArray();
        String[][] thePuzzle = puzzles[randInt.nextInt(SudokuPuzzle.getPuzzleArray().length)]; //chooses one puzzle
        return thePuzzle;
    }
}
