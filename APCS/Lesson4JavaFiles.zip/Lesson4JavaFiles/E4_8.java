
/**
 * Write a description of class E4_8 here.
 * 
 * @author Rachel Ware 
 * @version 9.27.16
 */

import java.util.Scanner;
public class E4_8
{
  public static void main(String[] args)
  {
      System.out.print("Enter a rectangle side width: ");
      Scanner in = new Scanner(System.in);
      int rectWidth = in.nextInt();
      System.out.println("");
      System.out.print("Enter a rectangle side length: ");
      int rectLength = in.nextInt();
      System.out.println("");
      System.out.println("Area: " + (rectWidth * rectLength));
      System.out.println("Perimeter: " + ((2*rectWidth) + (2*rectLength)));
      System.out.println("Diagonal length: " + Math.sqrt(Math.pow(rectWidth,2) + Math.pow(rectLength,2)));
      
    }
}
