
/**
 * Write a description of class E4_23 here.
 * Balloon class
 * 
 * @author Rachel Ware 
 * @version 9.27.16
 */
public class E4_23
{
   
   private double currentVolume;
   
    void addAir(double amount)
   {
       
    }
    
   double getVolume()
   {
       return currentVolume;
    }
    
   double getSurefaceArea()
   {
       return currentVolume;
    }
    
   double getRadius()
   {
       return currentVolume;
    }
}
