
/**
 * Write a description of class E4_3 here.
 * 
 * @author Rachel Ware 
 * @version 9.26.16
 */

import java.util.Scanner;
public class E4_3
{
   
   public static void main(String[] args)
   {
       System.out.print("Input a number: ");
       Scanner in = new Scanner(System.in);
       double number = in.nextInt();
       double square = number * number;
       double cube = number * number * number;
       double fourth = Math.pow(number,4);
       System.out.println("Squared: " + square);
       System.out.println("Cubed: " + cube);
       System.out.println("To the fourth power: " + fourth);
    }
}
