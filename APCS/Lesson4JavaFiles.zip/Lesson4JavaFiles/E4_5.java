
/**
 * Write a description of class E4_5 here.
 * 
 * @author Rachel Ware
 * @version 9.26.16
 */

import java.util.Scanner;
public class E4_5
{
   public static void main(String[] args)
   {
       System.out.print("Input an integer: ");
       Scanner in = new Scanner(System.in);
       int firstInt = in.nextInt();
       System.out.println("");
       System.out.print("Input another integer: ");
       int secondInt = in.nextInt();
       System.out.println("");
       System.out.printf("Sum:" + "%13d\n" , (firstInt + secondInt));
       System.out.printf("Difference:" +  "%6d\n",(firstInt - secondInt));
       System.out.printf("Product:" +  "%9d\n",(firstInt * secondInt));
       System.out.printf("Average:" + "%9d\n", ((firstInt + secondInt) / 2));
       System.out.printf("Distance:" + "%8d\n", (Math.abs(firstInt - secondInt)));
       System.out.printf("Maximum:" + "%9d\n", Math.max(firstInt, secondInt));
       System.out.printf("Minimum:" + "%9d\n", Math.min(firstInt, secondInt));

    }
}
