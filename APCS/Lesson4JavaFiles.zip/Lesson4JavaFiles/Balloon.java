
/**
 * Write a description of class Balloon here.
 * Balloon class (E4_23)
 * 
 * @author Rachel Ware 
 * @version 9.27.16
 */
public class Balloon
{
   private double currentVolume; //volume in cm cubed
   private double radius;  //radius in cm
   private double surfaceArea;
   
   /**
    * Constructs an uninflated balloon
    */
   public Balloon()
   {
       currentVolume = 0;
       radius = 0;
    }
    
    /**
    * 
    * @param amount
    */
    void addAir(double amount)
   {
       currentVolume = currentVolume + amount;
       radius = Math.pow((currentVolume*0.75)/(Math.PI),(1.0/3.0));
       surfaceArea = 4.0*Math.PI*Math.pow(radius,2);
    }
    
    /**
    * 
    * @return the current volume
    */
   double getVolume()
   {
       return currentVolume;
    }
    
    /**
    * 
    * @reurn the surface area of the balloon
    */
   double getSurfaceArea()
   {
       return surfaceArea;
    }
    
    /**
    * 
    * @return the radius
    */
   double getRadius()
   {
       return radius;
    }
}
