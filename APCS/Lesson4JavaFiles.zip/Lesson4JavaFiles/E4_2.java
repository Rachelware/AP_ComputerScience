
/**
 * Write a description of class E4_2 here.
 * 
 * @author Rachel Ware
 * @version 9.26.16
 */
public class E4_2
{
    public static final double WIDTH = 8.5;
    public static final double LENGTH = 11;
    
    public static void main(String[] args)
    {
        double diagonalLength = Math.sqrt(Math.pow(LENGTH,2) + Math.pow(WIDTH,2));
        double perimeter = (2* WIDTH) + (2*LENGTH);
        System.out.println("Perimeter: " + perimeter);
        System.out.println("Expected: 39.0");
        System.out.println("Diagonal: " + diagonalLength);
        System.out.println("Expected: 13.901438774457844");
    }
}
