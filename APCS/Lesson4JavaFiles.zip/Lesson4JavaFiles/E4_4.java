
/**
 * Write a description of class E4_4 here.
 * 
 * @author Rachel Ware
 * @version 9.26.16
 */

import java.util.Scanner;
public class E4_4
{
   public static void main(String[] args)
   {
       System.out.print("Input an integer: ");
       Scanner in = new Scanner(System.in);
       int firstInt = in.nextInt();
       System.out.println("");
       System.out.print("Input another integer: ");
       int secondInt = in.nextInt();
        System.out.println("");
       System.out.println("Sum: " + (firstInt + secondInt));
       System.out.println("Difference: " + (firstInt - secondInt));
       System.out.println("Product: " + (firstInt * secondInt));
       System.out.println("Average: " + ((firstInt + secondInt) / 2));
       System.out.println("Distance: " + (Math.abs(firstInt - secondInt)));
       System.out.println("Maximum: " + Math.max(firstInt, secondInt));
       System.out.println("Minimum: " + Math.min(firstInt, secondInt));
    }
}
