
/**
 * Write a description of class BalloonTester here.
 * 
 * @author Rachel Ware 
 * @version 9.28.16
 */
public class BalloonTester
{
   public static void main(String[] args)
   {
       Balloon inflatable = new Balloon();
       inflatable.addAir(100);
       System.out.println("Volume: " + inflatable.getVolume());
       System.out.println("Expected: 100");
       System.out.println("Surface Area: " + inflatable.getSurfaceArea());
       System.out.println("Expected: 104.11879415");
       System.out.println("Radius: " + inflatable.getRadius());
       System.out.println("Expected: 2.879411911");
       inflatable.addAir(100);
       System.out.println("Volume: " + inflatable.getVolume());
       System.out.println("Expected: 200");
       System.out.println("Surface Area: " + inflatable.getSurfaceArea());
       System.out.println("Expected: 165.3880481");
       System.out.println("Radius: " + inflatable.getRadius());
       System.out.println("Expected: 3.627831679");
    }
}
