
/**
 * Write a description of class Easter here.
 * Takes user input of a year and returns the month/day/year Easter is according to the algorithm.
 * @author Rachel Ware
 * @version 10.3.16
 */
import java.util.Scanner;
public class Easter
{
    public static void main(String[] args)
    {
        System.out.print("Enter a year: "); //prompts user input
        Scanner in = new Scanner(System.in); //takes user input
        int year = in.nextInt(); //puts user input into variable year
        int a = year%19;
        int b = year/100;
        int c = year%100;
        int d = b/4;
        int e = b%4;
        int g = (8 * b + 13)/25;
        int h = (19 * a + b - d -g + 15)%30;
        int j = c/4;
        int k = c%4;
        int m = (a + 11 * h)/319;
        int r = (2 * e + 2 * j - k - h + m + 32)%7;
        int n = (h - m + r + 90)/25; //finds the month
        int p = (h - m + r + n + 19)%32; //finds the day
        System.out.println("Easter: " + n + "/" + p + "/" + year);  //prints out the month/day/year of Easter
    }
}
