
/**
 * Write a description of class ex1_4 here.
 * 
 * @author Rachel Ware
 * @version 8/2/16
 */
public class ex1_4
{
       public static void main(String[] args)
       {
           System.out.print("$");
           System.out.println(1000*1.05);
           System.out.print("$");
           System.out.println(1000*1.05*1.05);
           System.out.print("$");
           System.out.println(1000*1.05*1.05*1.05);
        }
}
