
/**
 * Write a description of class ex1_6 here.
 * 
 * @author Rachel Ware
 * @version 8/22/16
 */
public class ex1_6
{
    public static void main(String args[])
    {
        System.out.println("****       *      ***** *    *  ******  *");
        System.out.println("*    *    *  *   *      *    *  *       *");
        System.out.println("******   ******  *      ******  ***     *");
        System.out.println("*  *    *      * *      *    *  *       *");
        System.out.println("*    *  *      *  ***** *    *  ******  *****");
        
        
    }
}
