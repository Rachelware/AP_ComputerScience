
/**
 * Write a description of class ex1_7 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ex1_7
{
    public static void main(String[] args)
    {
        System.out.println("  |||||");
        System.out.println(" +'''''+");
        System.out.println("(| - o |)");
        System.out.println(" |  ^  |");
        System.out.println(" | '-' |");
        System.out.println(" +_____+");
    }
}

