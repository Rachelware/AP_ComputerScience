/**
 * This is a class that tests the Deck class.
 */
public class DeckTester0 {
    /**
     * The main method in this class checks the Deck operations for consistency.
     *  @param args is not used.
     */
    public static void main(String[] args) {
        String[] ranks = {"ace", "2", "3", "4", "6", "7", "8", "9", "10", "jack", "queen", "king"};
        String[] suits = {"hearts", "spades", "clubs", "diamonds"};
        int[] pointValues = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13};
        
        
        String[] ArrayRank1 = {};
        String[] ArrayRank2 = {"Ace", "Jack", "4"};
        String[] ArrayRank3 = {"10", "King", "9"};
        
        String[] ArraySuits1 = {};
        String[] ArraySuits2 = {"spades", "diamonds", "clubs"};
        String[] ArraySuits3 = {"diamonds", "clubs", "spades"};
        
        int[] ArrayValues1 = {};
        int[] ArrayValues2 = {1, 11, 4};
        int[] ArrayValues3 = {10, 13, 9};
        
        Deck deck1 = new Deck(ArrayRank1, ArraySuits1, ArrayValues1);
        Deck deck2 = new Deck(ArrayRank2, ArraySuits2, ArrayValues2);
        Deck deck3 = new Deck(ArrayRank3, ArraySuits3, ArrayValues3);
        
        System.out.print(deck1);
        System.out.println(deck1.isEmpty());
        System.out.println(deck1.size());
        deck1.deal();
        System.out.print(deck1);
        System.out.println(deck1.isEmpty());
        System.out.println(deck1.size());
        deck1.deal();
        System.out.print(deck1);
        System.out.println(deck1.isEmpty());
        System.out.println(deck1.size());
        System.out.println("");
        
        System.out.println(deck2);
        System.out.println(deck2.isEmpty());
        System.out.println(deck2.size());
        deck2.deal();
        System.out.println(deck2);
        System.out.println(deck2.isEmpty());
        System.out.println(deck2.size());
        deck2.deal();
        System.out.println(deck2);
        System.out.println(deck2.isEmpty());
        System.out.println(deck2.size());
        System.out.println("");
        
        deck3.deal();
        System.out.println(deck3);
        System.out.println(deck3.isEmpty());
        System.out.println(deck3.size());
        deck3.deal();
        System.out.println(deck3);
        System.out.println(deck3.isEmpty());
        System.out.println(deck3.size());
        deck3.deal();
        System.out.println(deck3);
        System.out.println(deck3.isEmpty());
        System.out.println(deck3.size());
    }
}
