
/**
 * Write a description of class Student here.
 * 
 * @author Rachel Ware
 * @version 1.31.17
 */
public class Student extends Person
{
    private String major;
   
    /**
     * Constructor for objects of class Student
     */
    public Student(String name, String yearOfBirth, String major)
    {
        super(name, yearOfBirth);
        this.major = major;
    }
    
    public String toString()
    {
        String output = super.toString() + ", major: " + major;
        return output;
    }

}
