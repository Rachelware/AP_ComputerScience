import java.awt.Rectangle;
/**
 * It makes a BetterRectangle
 * 
 * @author Rachel Ware
 * @version 2.1.17
 */
public class BetterRectangle extends java.awt.Rectangle
{

    /**
     * Constructor for objects of class BetterRectangle
     */
    public BetterRectangle(int x, int y, int width, int height)
    {
        setLocation(x, y);
        setSize(width, height);
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public String getPerimeter()
    {
        int perimeter = width*2 + height*2;
        String output = "Perimeter: " + perimeter;
        return output;
    }
    
    public String getArea()
    {
        int area = width * height;
        String output = "Area: " + area;
        return output;
    }
    
}
