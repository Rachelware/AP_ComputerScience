
/**
 * Write a description of class Monthly here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Monthly extends Appointment
{
    private int year;
    private int month;
    private int day;
    
    /**
     * Constructor for objects of class Monthly
     */
    public Monthly(int year, int month, int day, String description)
    {
        super(year, month, day, description);
        this.year = year;
        this.month = month;
        this.day = day;
    }
    
    public boolean occursOn(int year, int month, int day)
    {
        if (year >= this.year && month >= this.month && day == this.day)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public String toString()
    {
        return super.toString();
    }
}
