
/**
 * Write a description of class Appointment here.
 * 
 * @author Rachel Ware
 * @version 2.1.17
 */
public class Appointment
{
    private String description;
    private int year;
    private int month;
    private int day;

    /**
     * Constructor for objects of class Appointment
     */
    public Appointment(int year, int month, int day, String description)
    {
        this.description = description;
        this.year = year;
        this.month = month;
        this.day = day;
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public boolean occursOn(int year, int month, int day)
    {
        if (this.year == year && this.month == year && this.day == day)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public String toString()
    {
        return description;
    }
}
