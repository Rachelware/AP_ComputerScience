
/**
 * Write a description of class Instructor here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Instructor extends Person
{
    private int salary;

    /**
     * Constructor for objects of class Instructor
     */
    public Instructor(String name, String yearOfBirth, int salary)
    {
        super(name, yearOfBirth);
        this.salary = salary;
    }
    
    public String toString()
    {
        String output = super.toString() + ", salary: " + salary;
        return output;
    }
}
