/**
 This program tests the Person, Student, and Instructor classes.
 */
public class test
{
   public static void main(String[] args)
   {
      Person woman = new Person("Marjorie", "1962");
      System.out.println(woman);

      Student sophmore = new Student("Helen", "1981", "Accounting");
      System.out.println(sophmore);

      Instructor instr = new Instructor("Mr. Henry", "1954", 45000);
      System.out.println(instr);
   }
}
