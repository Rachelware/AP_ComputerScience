/**
   Demonstration of the appointment classes
   Test:
   2017 10 31 --> Brush your teeth, Trick or Treat
   2017 3  1 --> Brush your teeth, Visit grandma, Dentist appointment
   2016 2 1 --> nothing
   2017 10 1 --> Brush your teeth, Visit grandma
   
*/

import java.util.Scanner;
import java.util.ArrayList;
public class AppointmentDemo
{
   public static void main(String[] args)
   {
      ArrayList <Appointment> appointments = new ArrayList <Appointment> (4);
      appointments.add(new Daily(2017, 1, 1, "Brush your teeth."));
      appointments.add(new Monthly(2017, 2, 1, "Visit grandma."));
      appointments.add(new Onetime(2017, 3, 1, "Dentist appointment."));
      appointments.add(new Onetime(2017, 10, 31, "Trick or Treat."));
      Scanner in = new Scanner(System.in);
      System.out.println("Enter 'add' to make new appointments or 'check' to check appointments:");
      String input = in.nextLine();
          if (input.equals("add"))
          {
              System.out.print("Enter a description: ");
              String description = in.nextLine();
              System.out.print("Enter a type (daily, monthly, or onetime): ");
              String type = in.next();
              System.out.print("Enter date (year, month, day):");
              int year = in.nextInt();
              int month = in.nextInt();
              int day = in.nextInt();
              if (type.equals( "daily"))
              {
                  appointments.add(new Daily(year, month, day, description));
              }
              else if (type.equals("monthly"))
              {
                  appointments.add(new Monthly(year, month, day, description));
                }
                else if (type.equals("onetime"))
                {
                    appointments.add(new Onetime(year, month, day, description));
                }
              System.out.println(appointments.get(appointments.size()-1));
          }
          else if (input.equals("check"))
          {
              System.out.print("Enter a date (year, month, day) to list "
                    + "appointments: ");
              int year = in.nextInt();
              int month = in.nextInt();
              int day = in.nextInt();
              for (int i = 0; i < appointments.size(); i++)
              {
                 if (appointments.get(i).occursOn(year, month, day))
                 {
                    System.out.println(appointments.get(i));
                 }
              }
            }
   }
}