
/**
 * Write a description of class Daily here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Daily extends Appointment
{
    private int year;
    private int month;
    private int day;
    /**
     * Constructor for objects of class Daily
     */
    public Daily(int year, int month, int day, String description)
    {
        super(year, month, day, description);
        this.year = year;
    }
    
    public boolean occursOn(int year, int month, int day)
    {
        if (year >= this.year && month >= this.month && day >= this.day)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public String toString()
    {
        return super.toString();
    }
}
