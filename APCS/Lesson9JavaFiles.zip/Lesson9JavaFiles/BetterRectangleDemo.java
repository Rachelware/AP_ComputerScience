/**
   A class to test BetterRectangle.
*/
public class BetterRectangleDemo
{
   public static void main(String[] args)
   {
      BetterRectangle rect = new BetterRectangle(5, 10, 5, 7);
      System.out.println(rect.getPerimeter());
      System.out.println(rect.getArea());
   }
}
