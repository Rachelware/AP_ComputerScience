
/**
 * Write a description of class Person here.
 * 
 * @author Rachel Ware
 * @version 1.31.17
 */
public class Person
{
    private String name;
    private String yearOfBirth;

    /**
     * Constructor for objects of class E9_8
     */
    public Person(String name, String yearOfBirth)
    {
        this.name = name;
        this.yearOfBirth = yearOfBirth;
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public String toString()
    {
        String output = "name: " + name + ", year of birth: " + yearOfBirth;
        return output;
    }
}
