
/**
 * Write a description of class E6_2B here.
 * gives the number of even and odd inputs
 * 
 * @author Rachel Ware 
 * @version 10.24.16
 */
import java.util.Scanner;
public class E6_2B
{
   public static void main (String[] args)
    {
        System.out.print("Input some integers, input q to quit: ");
        Scanner in = new Scanner(System.in);
        int even = 0;
        int odd = 0;
        while (in.hasNextInt())
        {
            int newInput = in.nextInt();
            if (newInput % 2 == 0)
            {
                even++;
            }
            else
            {
                odd++;
            }
        }
        System.out.println("number even: " + even);
        System.out.println("number odd: " + odd);
    }
}
