
/**
 * Write a description of class E6_19 here.
 * 
 * @author Rachel Ware 
 * @version 10.25.16
 */ 
import java.util.Random;
public class E6_19
{
    public static void main(String[] args)
    {
        int winCount = 0;
        for (int i = 0; i<1000; i++)
        {
            Random prize = new Random();
            int prizeDoor = prize.nextInt(3) + 1;
            Random choice = new Random();
            int choiceDoor = choice.nextInt(3) + 1;
            Random goat = new Random();
            int goatDoor = goat.nextInt(3) + 1;
            while (goatDoor == choiceDoor || goatDoor == prizeDoor)
            {
                goatDoor = goat.nextInt(3) + 1;
            }
            int changeDoor = choice.nextInt(3) +1;
            while (changeDoor == choiceDoor || changeDoor == goatDoor)
            {
                changeDoor = choice.nextInt(3) +1;
            }
            boolean win = false;
            if (changeDoor == prizeDoor)
            {
                win = true;
                winCount++;
            }
            else
            {
                win = false;
            }
        }
        //System.out.println("Changing wins " + (((float)winCount/1000)*100) + "% of the time");
        System.out.println("Changing won " + winCount + " out of 1000 times");
        winCount = 0;
        for (int i = 0; i<1000; i++)
        {
            Random prize = new Random();
            int prizeDoor = prize.nextInt(3) + 1;
            Random choice = new Random();
            int choiceDoor = choice.nextInt(3) + 1;
            Random goat = new Random();
            int goatDoor = goat.nextInt(3) + 1;
            while (goatDoor == choiceDoor || goatDoor == prizeDoor)
            {
                goatDoor = goat.nextInt(3) + 1;
            }
            boolean win = false;
            if (choiceDoor == prizeDoor)
            {
                win = true;
                winCount++;
            }
            else
            {
                win = false;
            }
        }
        //System.out.println("Sticking with it wins " + (((float)winCount/1000)*100) + "% of the time");
        System.out.println("Sticking with it won " + winCount + " out of 1000 times");
    }
}
