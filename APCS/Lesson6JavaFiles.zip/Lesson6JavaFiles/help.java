
/**
 * Write a description of class help here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.util.Random;
public class help
{
    public static void main(String[] args)
    {
        int winCount = 0;
        for (int i = 0; i<1000; i++)
        {
        Random prize = new Random();
            int prizeDoor = prize.nextInt(3) + 1;
            System.out.println(prizeDoor);
            Random choice = new Random();
            int choiceDoor = choice.nextInt(3) + 1;
            System.out.println(choiceDoor);
            Random goat = new Random();
            int goatDoor = goat.nextInt(3) + 1;
            System.out.println(goatDoor);
            while (goatDoor == choiceDoor || goatDoor == prizeDoor)
            {
                goatDoor = goat.nextInt(3) + 1;
            }
            System.out.println(goatDoor);
            boolean win = false;
            if (choiceDoor == prizeDoor)
            {
                win = true;
                winCount++;
            }
            else
            {
                win = false;
            }
    }
    System.out.println("Changing wins " + winCount + "out of 1000 % of the time");
    System.out.println(winCount / 1000);
}
}
