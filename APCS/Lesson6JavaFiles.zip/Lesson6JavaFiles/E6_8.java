
/**
 * Write a description of class E6_8 here.
 * Prints a string input on separate lines
 * 
 * @author Rachel Ware 
 * @version 10.25.16
 */
import java.util.Scanner;
public class E6_8
{
    public static void main(String[] args)
    {
        System.out.print("input a String: ");
        Scanner in = new Scanner(System.in);
        String word = in.next();
        for (int i = 0; i < word.length(); i++)
        {
            System.out.println(word.substring(i, i+1));
        }
    }
}
