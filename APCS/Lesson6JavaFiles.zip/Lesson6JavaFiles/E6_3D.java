
/**
 * Write a description of class E6_3D here.
 * reads a String input and gives the number of vowels
 * 
 * @author Rachel Ware
 * @version 10.24.16
 */

import java.util.Scanner;
public class E6_3D
{
    public static void main(String[] args)
    {
        System.out.print("Input a string: ");
        Scanner in = new Scanner(System.in);
        String word = in.next();
        int counter = 0;
        for (int i = 0; i < word.length(); i++)
        {
            if (word.substring(i, i+1).equals("a") || word.substring(i, i+1).equals("e") || word.substring(i, i+1).equals("i") || word.substring(i, i+1).equals("o") || word.substring(i, i+1).equals("u"))
            {
                counter = counter + 1;
            }
        }
        System.out.println("there are " + counter + " vowels");
    }
}
 