
/**
 * Write a description of class E6_9 here.
 * 
 * @author Rachel Ware 
 * @version 10.25.16
 */
import java.util.Scanner;
public class E6_9
{
    public static void main(String[] args)
    {
        System.out.print("input a String: ");
        Scanner in = new Scanner(System.in);
        String word = in.next();
        String reverse = "";
        for (int i = word.length(); i > 0; i--)
        {
            reverse = reverse + word.substring(i-1,i);
        }
        System.out.println(reverse);
    }
}
