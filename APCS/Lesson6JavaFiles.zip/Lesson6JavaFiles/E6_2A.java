
/**
 * Write a description of class E6_2A here.
 * gives the smallest and largest of the inputs
 * 
 * @author Rachel Ware
 * @version 10.21.16
 */
import java.util.Scanner;
public class E6_2A
{
    public static void main (String[] args)
    {
        System.out.print("Input some integers, input q to quit: ");
        Scanner in = new Scanner(System.in);
        int firstInput = in.nextInt();
        int min = firstInput;
        int max = firstInput;
        while (in.hasNextInt())
        {
            int newInput = in.nextInt();
            min = Math.min(newInput, min);
            max = Math.max(newInput, max);
        }
        System.out.println("smallest: " + min);
        System.out.println("largest: " + max);
    }
}
