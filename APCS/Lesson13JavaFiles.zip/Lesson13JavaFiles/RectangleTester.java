import java.util.Scanner;
/**
 * Write a description of class RectangleTester here.
 * 
 * @author Rachel Ware
 * @version 2.27.17
 */
public class RectangleTester
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        System.out.print("input a width: ");
        int width = in.nextInt();
        System.out.print("input a height: ");
        int height = in.nextInt();
        Rectangle rect = new Rectangle(width, height);
        int area = rect.getArea();
        System.out.println("Area: " + area);
    }
}
