
/**
 * Write a description of class Stringy here.
 * 
 * @author Rachel Ware 
 * @version 2.27.17
 */
public class Stringy
{
    /**
     * Constructor for objects of class Stringy
     */
    public Stringy()
    {
        
    }

    public static String reverse(String text)
    {
        if (text.isEmpty())
        {
            return text;
        }
        else
        {
            return reverse(text.substring(1)) + text.charAt(0);
        }
    }
    
    public static boolean find(String text, String str)
    {
        if (text.equals(str))
        {
            return true;
        }
        else if (text.length() < str.length())
        {
            return false;
        }
        else if (text.substring(0, str.length()).equals(str))
        {
            return true;
        }
        else 
        {
            return find(text.substring(1, text.length()), str);
        }
    }
}
