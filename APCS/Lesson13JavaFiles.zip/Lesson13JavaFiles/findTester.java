import java.util.Scanner;
/**
 * Write a description of class findTester here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class findTester
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        System.out.print("input a word: ");
        String text = in.nextLine();
        System.out.print("input a string: ");
        String str = in.nextLine();
        System.out.println(Stringy.find(text, str));
    }
}
