
/**
 * Write a description of class E13_9 here.
 * 
 * @author Rachel Ware
 * @version 3.1.17
 */
public class E13_9
{
    /**
     * Constructor for objects of class E13_9
     */
    public E13_9()
    {

    }
    
    public static int computeSum(int[] array)
    {
        if (array.length == 1)
        {
            return array[0];
        }
        else
        {
            int[] newArray = new int[array.length - 1];
            for (int i = 0; i < array.length - 1; i++)
            {
                newArray[i] = array[i + 1];
            }
            int sum = computeSum(newArray);
            return sum + array[0];
        }   
    }
}
