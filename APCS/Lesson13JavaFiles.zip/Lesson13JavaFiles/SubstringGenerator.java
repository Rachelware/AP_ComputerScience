import java.util.ArrayList;
import java.util.Scanner;
/**
 * Write a description of class SubstringGenerator here.
 * 
 * @author Rachel Ware
 * @version 3.2.17
 */
public class SubstringGenerator
{
    /**
     * Constructor for objects of class E13_12
     */
    public SubstringGenerator()
    {

    }
    
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter a word: ");
        String word = in.nextLine();
        System.out.println(allSubstrings(word));
    }
    
    public static String allSubstrings(String word)
    {
        if (word.length() == 1)
        {
            return word + ", and ''";
        }
        else
        {
            ArrayList <String> arraylist = new ArrayList <String>();
            for (int i = 1; i < word.length() + 1; i++)
            {
                arraylist.add(word.substring(0, i));
            }
            String answer = "" + arraylist.get(0);
            for (int i = 1; i < arraylist.size(); i++)
            {
                answer = answer + ", " + arraylist.get(i);
            }
            return answer + ", " + allSubstrings(word.substring(1, word.length()));
        }
    }
}
