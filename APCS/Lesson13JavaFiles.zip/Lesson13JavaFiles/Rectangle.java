
/**
 * Write a description of class Rectangle here.
 * 
 * @author Rachel Ware
 * @version 2.27.17
 */
public class Rectangle
{
    private int width;
    private int height;

    /**
     * Constructor for objects of class E13_1
     */
    public Rectangle(int width, int height)
    {
        this.width = width;
        this.height = height;
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public int getArea()
    {
        if (width == 1)
        {
            return height;
        }
        else
        {
            Rectangle smallerRectangle = new Rectangle(width - 1, height);
            int smallerArea = smallerRectangle.getArea();
            return smallerArea + height;
        }
    }
}
