
/**
 * Write a description of class ArrayTester here.
 * 
 * @author Rachel Ware
 * @version 3.2.17
 */
public class ArrayTester
{
    public static void main(String[] args)
    {
        int[] Array = {1, 2, 3, 4, 5};
        System.out.print(E13_9.computeSum(Array));
    }
}
