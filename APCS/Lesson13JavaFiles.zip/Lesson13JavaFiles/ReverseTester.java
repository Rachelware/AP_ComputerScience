import java.util.Scanner;
/**
 * Write a description of class StringyTester here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ReverseTester
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        System.out.print("input a word: ");
        String word = in.nextLine();
        System.out.println("Reversed: " + Stringy.reverse(word));
    }
}
