
/**
 * Write a description of class Person here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Person implements Measurable
{
    private String name;
    private double height;
    
    public Person(String name, double height)
    {
        this.height = height;
        this.name = name;
    }

    public double getHeight()
    {
        return height;
    }
    
    public double getMeasure()
    {
        return height;
    }
    
    public String getName()
    {
        return name;
    }
}
