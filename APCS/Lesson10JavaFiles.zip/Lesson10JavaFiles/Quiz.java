
/**
 * Write a description of class Quiz here.
 * 
 * @author Rachel Ware
 * @version 2.6.17
 */
public class Quiz implements Measurable
{
    private double score;
    private String letterGrade;
    
    public Quiz(double score, String letterGrade)
    {
        this.score = score;
        this.letterGrade = letterGrade;
    }
    
    public double getMeasure()
    {
        return score;
    }
    
    public double getScore()
    {
        return score;
    }
    
    public String getGrade()
    {
        return letterGrade;
    }
}
