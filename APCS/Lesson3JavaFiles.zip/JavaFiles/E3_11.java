
/**
 * Write a description of class E3_11 here.
 * 
 * @author Rachel Ware
 * @version 9.15.16
 */
public class E3_11
{
   public static void main(String[] args)
   {
       Letter dearJohn = new Letter("John", "Mary");
       dearJohn.addLine("I am sorry we must part.");
       dearJohn.addLine("I wish you all the best.");
       String finalLetter = dearJohn.getText();
       System.out.println(finalLetter);
    }
}
