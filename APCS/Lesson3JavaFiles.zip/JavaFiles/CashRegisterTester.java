
/**
 * Write a description of class CashRegisterTester here.
 * A class to test the CashRegister class.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CashRegisterTester
{
   public static void main(String[] args)
   {
      CashRegister register = new CashRegister(.09);

      register.recordPurchase(29.50);
      register.recordPurchase(9.25);
      register.receivePayment(50);

      double change = register.giveChange();
      String reciptTicket = register.printRecipt();
      System.out.println(change);
      System.out.println("Expected: 11.25");
      System.out.println(reciptTicket);
            
   }
}

