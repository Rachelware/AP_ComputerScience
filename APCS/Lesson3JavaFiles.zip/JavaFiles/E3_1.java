
/**
 * Write a description of class E3_1 here.
 * Counter button
 * 
 * @author Rachel Ware
 * @version 9/9/16
 */

   public class E3_1
{
   public static void main(String[] args)
   {
      Counter tally = new Counter();
      tally.click();
      tally.click();
      tally.undo();
      tally.undo();
      tally.undo();
      int result = tally.getValue(); // Sets result to value
      System.out.print("result: ");
      System.out.println(result);
      System.out.println("Expected: 0");
   }
}

