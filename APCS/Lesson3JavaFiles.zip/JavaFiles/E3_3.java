
/**
 * Write a description of E3_3 here.
 * Bank Account tester
 * @author Rachel Ware
 * @version 9.12.16
 */
public class E3_3
{
   public static void main(String[] args)
   {
      BankAccount myAccount = new BankAccount(0);
      myAccount.deposit(1000);
      myAccount.withdraw(500);
      myAccount.withdraw(400);
      double endBalance = myAccount.getBalance();
      System.out.println(endBalance);
      System.out.println("Expected: 100.0");
    }
}
