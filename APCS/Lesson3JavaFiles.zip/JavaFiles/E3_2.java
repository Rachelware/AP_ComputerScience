
/**
 * Write a description of class E3_2 here.
 * Counter limit
 * @author Rachel Ware 
 * @version 9/12/16
 */
public class E3_2
{
    public static void main(String[] args)
    {
      Counter tally = new Counter();
      tally.setLimit(5);
      tally.click();
      tally.click();
      tally.click();
      tally.click();
      tally.click();
      tally.click();
      tally.click();
      int result = tally.getValue(); // Sets result to value
      System.out.print("result: ");
      System.out.println(result);
      System.out.println("Expected: 5");
    }
}
