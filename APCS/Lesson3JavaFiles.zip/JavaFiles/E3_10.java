
/**
 * Write a description of class E3_10 here.
 * 
 * @author Rachel Ware
 * @version 9.14.16
 */
public class E3_10
{
  public static void main(String[] args)
  {
      Product lamp = new Product("lamp",48);  //makes product
      Product desk = new Product("desk", 120);
      System.out.println(lamp.getName() + " price:" + lamp.getPrice()); //prints item and price
      System.out.println("Expected: 48");
      System.out.println(desk.getName() + " price:" + desk.getPrice());
      System.out.println("Expected: 120");
      lamp.reducePrice(5); //reduces price by 5 dollars
      desk.reducePrice(5);
      System.out.println(lamp.getName() + " price:" + lamp.getPrice());  //prints item price
      System.out.println("Expected: 43");
      System.out.println(desk.getName() + " price:" + desk.getPrice());
      System.out.println("Expected: 115");
      
  }
}
