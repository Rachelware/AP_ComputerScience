
/**
 * Write a description of class Battery here.
 * 
 * Models a rechargable battery that drains and recharges to its original capacity.
 * 
 * @author Rachel Ware 
 * @version 9.16.16
 * 
 * 
 */
public class Battery
{
    // instance variables
    private double fullCapacity;  //maximum capacity of the battery/ amount when full
    private double currentCapacity;  //How much charge is in the battery currently

    /**
     * Constructs a Battery with full charge and sets its capacity.
     * @param capacity the maximum capacity
     */
    public Battery(double capacity)
    {
        fullCapacity = capacity;
        currentCapacity = capacity;
    }
    
    /**
     * Takes charge out of the battery.
     * @param aomunt the amount of charge lost
     */
    public void drain(double amount)
    {
        currentCapacity = currentCapacity - amount;
        currentCapacity = Math.max(currentCapacity,0);
    }
    
    /**
     * Charges the battery back to full capacity.
     */
    public void charge()
    {
        currentCapacity = fullCapacity;
    }
    
    /**
     * Gets the curent capacity of the Battery.
     * @return the current capacity
     */
    public double getRemainingCapacity()
    {
       return currentCapacity; 
    }
}
