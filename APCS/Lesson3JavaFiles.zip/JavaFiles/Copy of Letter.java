
/**
 * Write a description of class Letter here.
 * 
 * @author Rachel Ware 
 * @version 9.15.16
 */
public class Letter
{
    // instance variables - replace the example below with your own
    private String textForm;
    private String intro;
    private String body;
    private String closing;

    /**
     * Constructor for objects of class Letter
     */
    public Letter(String from, String to)
    {
        // initialise instance variables
        intro = "Dear " + from + ":\n \n";
        closing ="\nSincerely,\n" + "\n" + to;
        body = "";
    }

    public void addLine (String line)
    {
       //adds line of text
       body = body + line + "\n";
    }
    
    public String getText()
    {
       textForm = intro + body + closing;
        return textForm;
       // reurn text of letter
    }
    
}
