
/**
 * Write a description of class Product here.
 * 
 * Product class
 * 
 * @author Rachel Ware 
 * @version 9.14.16
 */
public class Product
{
    private String name;
    private double price;
    
    public Product(String item, double amount)
    {
        name = item;
        price = amount;
    }
    
    public String getName()
    {
       return name;
    }
    
    public double getPrice()
    {
        return price;
    }
    
    public double reducePrice(double amount)
    {
        price = price - amount;
        return price;
    }
}
