
/**
 * Write a description of class BatteryTester here.
 * 
 * @author Rachel Ware 
 * @version 9.16.16
 */
import java.lang.reflect.*;
import java.util.*;
public class BatteryTester
{
    public static void main(String[] args) throws SecurityException
    {
        try {
            Method batteryChargeMethod = Battery.class.getMethod("charge");
            Class[] types = new Class[1];
            types[0] = double.class;
            Method batteryDrainMethod = Battery.class.getMethod("drain", types);
            
            TestSet set1 = new TestSet(20000.0);
            set1.addTest(batteryDrainMethod, 12345.6, 7654.4);
            set1.addTest(batteryDrainMethod, 12000.0, 0.0);
            set1.addTest(batteryChargeMethod, 20000.0);
            set1.addTest(batteryChargeMethod, 20000.0);
            set1.addTest(batteryDrainMethod, 1000.0, 19000.0);
            set1.runTests();
    
            TestSet set2 = new TestSet(10.0);
            set2.addTest(batteryChargeMethod, 10.0);
            set2.addTest(batteryDrainMethod, 0.4, 9.6);
            set2.addTest(batteryDrainMethod, 0.0001, 9.5999);
            set2.addTest(batteryDrainMethod, 4.1, 5.4999);
            set2.addTest(batteryChargeMethod, 10.0);
            set2.addTest(batteryDrainMethod, 12000.0, 0.0);
            set2.runTests();
        } catch (NoSuchMethodException e) {
            System.err.println("Failed to find method with the required signature");
            e.printStackTrace();
        }
    }
    
}

class TestSet
{
    private double initialCapacity;
    private Battery battery;
    private List<Test> tests = new ArrayList<Test>();
    
    public TestSet(double capacity)
    {
        initialCapacity = capacity;
    }

    public void addTest(Method method, double argument, double expectedValue)
    {
        tests.add(new Test(method, argument, expectedValue));
    }
    
    public void addTest(Method method, double expectedValue)
    {
        tests.add(new Test(method, expectedValue));
    }

    public void runTests()
    {
        int successfulTests = 0;
        
        try {
            battery = new Battery(initialCapacity);
        } catch (Exception e) {
            System.err.println("Caught exception while initializing battery with capacity: "+initialCapacity);
            e.printStackTrace();
        }
        System.out.println("\nBattery initialized with initial capacity: "+initialCapacity);
        
        if (battery != null) {
            for (Test test : tests) 
            {
                try {
                    if (runTest(battery, test)) {
                        successfulTests++;
                    }
                } catch (Exception e) {
                    System.err.println("Caught exception while running test: "+test);
                    e.printStackTrace();
                }
            }
        }
        
        System.out.println("Test Summary: "+successfulTests+" successful out of "+tests.size());
    }
    
    private boolean runTest(Battery battery, Test test) throws IllegalAccessException,
                     IllegalArgumentException,
                     InvocationTargetException
    {
        if (test.argument == null) {
            test.method.invoke(battery);
        } else {
            test.method.invoke(battery, test.argument.doubleValue());
        }
        
        double remaining = battery.getRemainingCapacity();
        boolean success = remaining == test.expectedValue;
        System.out.println(test+" expected: "+test.expectedValue+" actual: "+remaining+(success ? "" : " - FAILED"));
        return success;
    }
}

class Test
{
    Method method;
    Double argument;
    double expectedValue;
    
    public Test(Method method, double argument, double expectedValue) 
    {
        this.method = method;
        this.argument = new Double(argument);
        this.expectedValue = expectedValue;
    }
    
    public Test(Method method, double expectedValue) 
    {
        this.method = method;
        this.argument = null;
        this.expectedValue = expectedValue;
    }
    
    public String toString() 
    {
        return "Test calling "+method.getName()+(argument == null ? "" : " with argument "+argument);
    }
}

