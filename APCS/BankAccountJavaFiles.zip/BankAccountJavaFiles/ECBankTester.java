
/**
 * Write a description of class ExtraCreditAccountTester here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ECBankTester
{
    public static void main(String[] args)
    {
        BankAccount account = new BankAccount("Savings", 5000.0);
        boolean success = account.deposit(50.0);
        System.out.println("Deposit should succeed. Did it succeed? "+success);
        System.out.println("Expected balance: $5050.00");
        System.out.printf("Actual balance: $%7.2f\n", account.getBalance());
        
        success = account.withdraw(100.0);
        System.out.println("Withdrawal should succeed. Did it succeed? "+success);
        System.out.println("Expected balance: $4950.00");
        System.out.printf("Actual balance: $%7.2f\n", account.getBalance());
        
        success = account.cashCheck(250.0);
        System.out.println("Check cashing should fail. Did it succeed? "+success);
        System.out.println("Expected balance: $4950.00");
        System.out.printf("Actual balance: $%7.2f\n", account.getBalance());
        
        BankAccount account2 = new BankAccount("Checking", 0.0);
        success = account2.withdraw(100.0);
        System.out.println("Withdrawal should fail. Did it succeed? "+success);
        System.out.println("Expected balance: $0.00");
        System.out.printf("Actual balance: $%4.2f\n", account2.getBalance());
        
        success = account.transferTo(account2, 1000.0);
        System.out.println("Transfer should succeed. Did it succeed? "+success);
        System.out.println("Expected balance: $3950.00");
        System.out.printf("Actual balance: $%7.2f\n", account.getBalance());
        System.out.println("Expected balance account2: $1000.00");
        System.out.printf("Actual balance account2: $%7.2f\n", account2.getBalance());
        
        success = account2.transferTo(account, 1001.0);
        System.out.println("Transfer should fail. Did it succeed? "+success);
        System.out.println("Expected balance: $3950.00");
        System.out.printf("Actual balance: $%7.2f\n", account.getBalance());
        System.out.println("Expected balance account2: $1000.00");
        System.out.printf("Actual balance account2: $%7.2f\n", account2.getBalance());
        
        success = account2.cashCheck(250.0);
        System.out.println("Check cashing should succeed. Did it succeed? "+success);
        System.out.println("Expected balance: $750.00");
        System.out.printf("Actual balance: $%6.2f\n", account2.getBalance());

        BankAccount account3 = new BankAccount("CertificateOfDeposit", 500.0, 0.06);
        success = account3.collectInterest(5);
        System.out.println("Collecting interest should succeed. Did it succeed? "+success);
        System.out.println("Expected balance: $669.11");
        System.out.printf("Actual balance: $%6.2f\n", account3.getBalance());
        
        success = account3.withdraw(200.0);
        System.out.println("Withdrawal should succeed. Did it succeed? "+success);
        System.out.println("Expected balance: $469.11");
        System.out.printf("Actual balance: $%7.2f\n", account3.getBalance());

        BankAccount account4 = new BankAccount("CertificateOfDeposit", 3000.0);
        success = account4.transferTo(account3, 2000.0);
        System.out.println("Transfer should succeed. Did it succeed? "+success);
        System.out.println("Expected balance: $1000.00");
        System.out.printf("Actual balance: $%7.2f\n", account4.getBalance());
        System.out.println("Expected balance account3: $2469.11");
        System.out.printf("Actual balance account3: $%7.2f\n", account3.getBalance());

        success = account4.collectInterest(3);
        System.out.println("Collecting interest should succeed. Did it succeed? "+success);
        System.out.println("Expected balance: 848.97");
        System.out.printf("Actual balance: $%6.2f\n", account4.getBalance());
    }
}
