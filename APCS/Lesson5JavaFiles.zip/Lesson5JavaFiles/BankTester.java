/**
 * Write a description of class SimpleAccountTester here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BankTester
{
    public static void main(String[] args)
    {
        BankAccount account = new BankAccount("Savings", 5000.0);
        boolean success = account.deposit(50.0);
        System.out.println("Deposit should succeed. Did it succeed? "+success);
        System.out.println("Expected balance: $5050.00");
        System.out.printf("Actual balance: $%7.2f\n", account.getBalance());
        
        success = account.withdraw(100.0);
        System.out.println("Withdrawal should succeed. Did it succeed? "+success);
        System.out.println("Expected balance: $4950.00");
        System.out.printf("Actual balance: $%7.2f\n", account.getBalance());
        
        success = account.cashCheck(250.0);
        System.out.println("Check cashing should fail. Did it succeed? "+success);
        System.out.println("Expected balance: $4950.00");
        System.out.printf("Actual balance: $%7.2f\n", account.getBalance());
        
        BankAccount account2 = new BankAccount("Checking", 0.0);
        success = account2.withdraw(100.0);
        System.out.println("Withdrawal should fail. Did it succeed? "+success);
        System.out.println("Expected balance: $0.00");
        System.out.printf("Actual balance: $%4.2f\n", account2.getBalance());
        
        success = account.transferTo(account2, 1000.0);
        System.out.println("Transfer should succeed. Did it succeed? "+success);
        System.out.println("Expected balance: $3950.00");
        System.out.printf("Actual balance: $%7.2f\n", account.getBalance());
        System.out.println("Expected balance account2: $1000.00");
        System.out.printf("Actual balance account2: $%7.2f\n", account2.getBalance());
        
        success = account2.transferTo(account, 1001.0);
        System.out.println("Transfer should fail. Did it succeed? "+success);
        System.out.println("Expected balance: $3950.00");
        System.out.printf("Actual balance: $%7.2f\n", account.getBalance());
        System.out.println("Expected balance account2: $1000.00");
        System.out.printf("Actual balance account2: $%7.2f\n", account2.getBalance());
        
        success = account2.cashCheck(250.0);
        System.out.println("Check cashing should succeed. Did it succeed? "+success);
        System.out.println("Expected balance: $750.00");
        System.out.printf("Actual balance: $%6.2f\n", account2.getBalance());
    }
}
