
/**
 * Write a description of class E5_17 here.
 * 
 * @author Rachel Ware
 * @version 10.11.16
 */
import java.util.Scanner;
public class E5_17
{
    public static void main(String[] args)
    {
        System.out.print("Input income: ");
        Scanner in = new Scanner(System.in);
        int total = in.nextInt();
        double tax = 0;
        if (total > 0)
        {
            tax = tax + Math.min(total, 50000) * .01;
        }
        if (total > 50000)
        {
            tax = tax + Math.min((total- 50000), 25000) * .02;
        }
        if (total > 75000)
        {
            tax = tax + Math.min(((total- 50000) -25000), 25000) * .03;
        }
        if (total > 100000)
        {
            tax = tax + Math.min((((total- 50000) -25000) -25000), 150000) * .04;
        }
        if (total > 250000)
        {
            tax = tax + Math.min(((((total- 50000) -25000) -25000) - 150000), 250000) * .05;
        }
        if (total > 500000)
        {
            tax = tax + Math.min((((((total- 50000) -25000) -25000) - 150000)-250000), 500000) * .06;
        }
        System.out.println("Income tax: " + tax);
    }
}
