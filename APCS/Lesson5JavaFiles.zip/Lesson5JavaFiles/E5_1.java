
/**
 * Write a description of class E5_1 here.
 * Takes an integer and tells whether it is positive, negative, or zero.
 * 
 * @author Rachel Ware 
 * @version 10.10.16
 */
import java.util.Scanner;
public class E5_1
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        System.out.print("Input an integer: ");
        int integer = in.nextInt();
        if (integer < 0)
        {
            System.out.println("The integer is negative");
        }
        else if (integer == 0)
        {
            System.out.println("The integer is 0");
        }
        else
        {
            System.out.println("The integer is positive");
        }
    }
}
