
/**
 * Write a description of class BankAccount here.
 * 
 * Constructs a bank account of type Checking or Savings and allows deposits, withdrawals,
 * check writing, and transfers between accounts.
 * 
 * @author Rachel Ware
 * @version 10.17.16
 */
public class BankAccount
{
    // instance variables
    private String type;   //account type
    private double balance;  //currentbalance

    /**
     * Constructor for objects of class BankAccount
     * 
     * @param accountType  can be "Checking" or "Savings"
     * @param initialBalance  non-negative starting balance of the BankAccount
     */
    public BankAccount(String accountType, double initialBalance)
    {
            type = accountType;
            balance = initialBalance;
    }

    /**
     * Deposits a given amount into the bank account
     * 
     * @param   amount  a positive, non-zero amount to be deposited
     * @return  true if operation is successful, false if it failed
     */
    public boolean deposit(double amount)
    {
        if (amount > 0)
        {
         balance = balance + amount;
         return true;
        }
        else
        {
         return false;
        }
    }
    
    /**
     * Withdraws a given amount from the bank account
     * 
     * @param  amount   a positive, non-zero amount to be withdrawn
     * @return true if operation is successful, false if it failed
     */
    public boolean withdraw(double amount)
    {
        if (amount > 0)
        {
            double tempBalance = balance - amount;
            if (tempBalance >=0)
            {
                balance = tempBalance;
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }
    
    /**
     * Subtracts a given amount from a Checking type bank account for a cashed check.
     * 
     * @param  amount   a positive, non-zero amount taken out of the account by a cashed check
     * @return true if operation is successful, false if it failed
     */
    public boolean cashCheck(double amount)
    {
        if (type.equals("Checking") && amount > 0)
        {
           double tempBalance = balance - amount;
           if (tempBalance < 0)
            {
                return false;
            }
             else
            {
                balance = tempBalance;
                return true;
             }
            }
            else
            {
                return false;
            }
        }
    
    /**
     * Transfers a given amount from the current bank account to another account
     * 
     * @param  account   the bank account to transfer to
     * @param  amount    a positive, non-zero amount to be transferred
     * @return true if operation is successful, false if it failed
     */
    public boolean transferTo(BankAccount account, double amount)
    {
        if ( amount > 0)
        {
          double tempThisAccount = balance - amount;
          double tempOtherAccount = account.getBalance() + amount;
          if (tempThisAccount >= 0 && tempOtherAccount >= 0)
          {
              balance = tempThisAccount;
              account.balance = tempOtherAccount;
              return true;
          }
          else
          {
              return false;
          }
        }
        else
        {
            return false;
        }
    }
    
    /**
     * Returns the current amount of the bank account
     * 
     * @return  the current balance
     */
    public double getBalance()
    {
        return balance;
    }
}
