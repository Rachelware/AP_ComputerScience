
/**
 * Write a description of class E5_7 here.
 * Takes input of three integers and tells whether they were inputed in order, ascending or descending.
 * @author Rachel Ware 
 * @version 10.10.16
 */
import java.util.Scanner;
public class E5_7
{
   public static void main(String[] args)
   {
       Scanner in = new Scanner(System.in);
       System.out.print("Input an integer: ");
       int first = in.nextInt();
       System.out.print("Input a second integer: ");
       int second = in.nextInt();
       System.out.print("Input a third integer: ");
       int third = in.nextInt();
       if (first <= second && second <= third)
       {
           System.out.println("in order");
        }
        else if (third <= second && second <= first)
        {
            System.out.println("in order");
        }
        else 
        {
            System.out.println("not in order");
        }
    }
}
