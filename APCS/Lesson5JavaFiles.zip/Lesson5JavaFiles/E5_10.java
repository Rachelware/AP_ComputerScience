
/**
 * Write a description of class E5_10 here.
 * 
 * @author Rachel Ware 
 * @version 10.12.15
 */
import java.util.Scanner;
public class E5_10
{
    public static void main (String[] args)
    {
        
       Scanner in = new Scanner(System.in);
       System.out.print("Input a 'C' for celsius or 'F' for Fahrenheit: ");
        String tempUnit = in.next();
       System.out.print("Input a temperature: ");
       double temp = in.nextDouble();
       System.out.print("Input a 'm' for meters or 'ft' for feet: ");
       String altUnit = in.next();
       System.out.print("Input an altitude: ");
       double alt = in.nextDouble();
       double meterRelatedTemp;
       if (tempUnit.equals("C") && altUnit.equals("m"))
       {
           meterRelatedTemp = temp + (alt/300); //calculates the temperature of water in relationship
                                                // to boiling and freezing points
           if (meterRelatedTemp <= 0)
           {
               System.out.println("solid");
            }
            else if (meterRelatedTemp >= 100)
            {
                System.out.println("gaseous");
            }
            else
            {
                System.out.println("liquid");
            }
        }
        else if (tempUnit.equals("C") && altUnit.equals("ft"))
       {
           meterRelatedTemp = temp + (alt/1000);
           if (meterRelatedTemp <= 0)
           {
               System.out.println("solid");
            }
            else if (meterRelatedTemp >= 100)
            {
                System.out.println("gaseous");
            }
            else
            {
                System.out.println("liquid");
            }
        }
        else if (tempUnit.equals("F") && altUnit.equals("m"))
        {
            meterRelatedTemp = temp + (alt/300);
           if (meterRelatedTemp <= 32)
           {
               System.out.println("solid");
            }
            else if (meterRelatedTemp < 212)
            {
                System.out.println("liquid");
            }
            else
            {
                System.out.println("gaseous");
            }
        }
        else if (tempUnit.equals("F") && altUnit.equals("ft"))
        {
            meterRelatedTemp = temp + (alt/1000);
           if (meterRelatedTemp <= 32)
           {
               System.out.println("solid");
            }
            else if (meterRelatedTemp < 212)
            {
                System.out.println("liquid");
            }
            else
            {
                System.out.println("gaseous");
            }
        }
        else
        {
            System.out.println("Error");
        }
    }
}
