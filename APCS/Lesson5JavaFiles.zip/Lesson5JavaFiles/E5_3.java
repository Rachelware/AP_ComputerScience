
/**
 * Write a description of class E5_3 here.
 * Takes an integer and tells how many digits it has.
 * 
 * @author Rachel Ware 
 * @version 10.10.16
 */
import java.util.Scanner;
public class E5_3
{
   public static void main(String[] args)
   {
       Scanner in = new Scanner(System.in);
       System.out.print("Input an integer: ");
       int integer = in.nextInt();
       int digits = 0;
       if (integer < 0)
       {
           integer = integer * -1;
        }
       if (integer >= 0)
       {
           digits = 1;
        }
       if (integer >= 10)
       {
           digits = 2;
        }
       if (integer >= 100)
       {
           digits = 3;
        }
       if (integer >= 1000)
        {
            digits = 4;
        }
       if (integer >= 10000)
        {
            digits = 5;
        }
       if (integer >= 100000)
        {
            digits = 6;
        }
       if (integer >= 1000000)
        {
            digits = 7;
        }
       if (integer >= 10000000)
        {
            digits = 8;
        }
       if (integer >= 100000000)
        {
            digits = 9;
        }
       if (integer >= 1000000000)
        {
            digits = 10;
        }
       System.out.println("the integer is " + digits + " digits");
    }
}
