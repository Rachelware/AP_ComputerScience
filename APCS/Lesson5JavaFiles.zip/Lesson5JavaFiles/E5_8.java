
/**
 * Write a description of class E5_8 here.
 * 
 * @author Rachel Ware
 * @version 10.10.16
 */
import java.util.Scanner;
public class E5_8
{
   public static void main (String[] args)
   {
       Scanner in = new Scanner(System.in);
       System.out.print("Input an integer: ");
       int first = in.nextInt();
       System.out.print("Input a second integer: ");
       int second = in.nextInt();
       System.out.print("Input a third integer: ");
       int third = in.nextInt();
       System.out.print("Input a fourth integer: ");
       int fourth = in.nextInt();
       if ((first == second && third == fourth) || (first == third && second == fourth) || (first == fourth && second == third))
       {
           System.out.println("two pairs");
        }
        else
        {
            System.out.println("not two pairs");
        }
    }
}
