/**
 * Searches and sorts an array of Monarchs using selection sort, insertion sort, merge sort,
 * sequential sort, and binary sort.
 * 
 * @author Rachel Ware 
 * @version 3.13.17
 */
public class SearchSortTester {
    public static void main( String args[]){
     Monarch[] mlist = new Monarch[8];
     
     mlist[0] = new Monarch("Queen Victoria", 1819);
     mlist[1] = new Monarch("Henry VIII", 1491);
     mlist[2] = new Monarch("William the Conqueror", 1023);
     mlist[3] = new Monarch("Queen Elizabeth II", 1926);
     mlist[4] = new Monarch("Peter The Great", 1672);
     mlist[5] = new Monarch("Louis XIV", 1643);
     mlist[6] = new Monarch("King Alfred", 849);
     mlist[7] = new Monarch("Queen Elizabeth I", 1533);
     
     System.out.println("------------Unsorted ------------");
     printMonarchs(mlist);
     
     System.out.println("------------Selection Sort------------ ");
     printMonarchs(selectionSort(mlist.clone()));
     
     System.out.println("------------Insertion Sort ------------");
     printMonarchs(insertionSort(mlist.clone()));
     
     System.out.println("------------Merge Sort------------");
     printMonarchs(mergeSort(mlist.clone()));
     
     /**
      * Optional: System.out.println("------------Quick Sort ------------");
     printMonarchs(quickSort(mlist.clone()));
     */
     
     System.out.println("\n------------Sequential Search ------------");
     System.out.println(sequentialSearch(mlist.clone(), "Peter The Great"));
    
     System.out.println("\n------------Binary Search ------------");
     System.out.println(binarySearch(sortByName(mlist.clone()), "Peter The Great"));
             
     System.out.println("\n------------Optional Binary Search ------------");
     System.out.println(binarySearch(sortByName(mlist.clone()), 1491));
    
    }
    
    public static void printMonarchs(Monarch[] mlist)
    {
     System.out.println("");
     System.out.println("List of Monarchs:");
     for( Monarch m : mlist)
     {
         System.out.println(m);
     }
     System.out.println("");
    }
    
    public static void printBirthYears(Monarch[] mlist)
    {
     for( Monarch m : mlist)
     {
         System.out.print(m.getYear() + " - ");
     }
     System.out.println("");
    }
    
    /**
     * Sorts Monarchs by birth year using selection sort.
     * 
     * @param  mlist   list of Monarchs
     * @return mlist   list of Monarchs
     */
    public static Monarch[] selectionSort(Monarch[] mlist)
    {
         for (int i = 0; i < mlist.length - 1; i++)
         {
             int miniPos = i;
             String nameSave = mlist[i].getName();
             for (int j = i + 1; j < mlist.length; j++)
             {
                 if (mlist[j].getYear() < mlist[miniPos].getYear())
                 {
                     miniPos = j;
                     nameSave = mlist[j].getName();
                 }
             }
             int minPos = miniPos;
             Monarch temp = new Monarch(nameSave, mlist[minPos].getYear());
             mlist[minPos] = mlist[i];
             mlist[i] = temp;
             printBirthYears(mlist);
         }
         return mlist;
    }
    
    /**
     * Sorts Monarchs by birth year using insertion sort.
     * 
     * @param  mlist   list of Monarchs
     * @return mlist   list of Monarchs
     */
    public static Monarch[] insertionSort(Monarch[] mlist)
    {
         for (int i = 1; i < mlist.length; i ++)
         {
             Monarch next = new Monarch(mlist[i].getName(), mlist[i].getYear());
             int j = i;
             while (j > 0 && mlist[j - 1].getYear() > next.getYear())
             {
                 mlist[j] = mlist[j - 1];
                 j--;
             }
             mlist[j] = next;
             printBirthYears(mlist);
         }
         return mlist;
    }
    
    /**
     * Sorts Monarchs by birth year using merge sort.
     * 
     * @param  mlist   list of Monarchs
     * @return mlist   list of Monarchs
     */
    public static Monarch[] mergeSort(Monarch[] mlist)
    {
         if (mlist.length <= 1) { return mlist; }
         Monarch[] first = new Monarch[mlist.length / 2];
         Monarch[] second = new Monarch[mlist.length - first.length];
         for (int i = 0; i < first.length; i++)
         {
             first[i] = mlist[i];
         }
         for (int i = 0; i <second.length; i++)
         {
            second[i] = mlist[first.length + i];
         }
         mergeSort(first);
         mergeSort(second);
         //merge(first, second, a);
         int iFirst = 0;
         int iSecond = 0;
         int j = 0;
         while (iFirst < first.length && iSecond < second.length)
          {  
             if (first[iFirst].getYear() < (second[iSecond].getYear()))
             {  
                mlist[j] = first[iFirst];
                iFirst++;
                
             }
             else
             {  
                 mlist[j] = second[iSecond];
                iSecond++;
                
             }
             j++;
             printBirthYears(mlist);
          }

         while (iFirst < first.length) 
         { 
            mlist[j] = first[iFirst]; 
            iFirst++; j++;
         }

         while (iSecond < second.length) 
         { 
            mlist[j] = second[iSecond]; 
            iSecond++; j++;
         }
         
         printBirthYears(mlist);        
         return mlist;
    }
    
    public static Monarch[] quickSort(Monarch[] mlist)
    {
        // quick sort is optional
         // code your algorithm here.  Include the following print
         // statement in each iteration of your algorithm so we can see
         // the list as it sorts/
         printBirthYears(mlist);
        
         return mlist;
    }
    
    /**
     * Sorts Monarchs by name using insertion sort.
     * 
     * @param  mlist   list of Monarchs
     * @return mlist   list of Monarchs
     */
    public static Monarch[] sortByName(Monarch[] mlist)
    {
         for (int i = 1; i < mlist.length; i ++)
         {
             Monarch next = new Monarch(mlist[i].getName(), mlist[i].getYear());
             int j = i;
             while (j > 0 && mlist[j - 1].getName().compareTo(next.getName()) > 0)
             {
                 mlist[j] = mlist[j - 1];
                 j--;
             }
             mlist[j] = next;
         }
         //printMonarchs(mlist);
         return mlist;
    }
    
    /**
     * Searches list of Monarchs for a given name using sequential search.
     * 
     * @param  mlist   list of Monarchs
     * @param  name    name of Monarch to find
     * 
     * @return mlist[i]   position of given name in the list
     */
    public static Monarch sequentialSearch(Monarch[] mlist, String name)
    {
         int i = 0;
         for (Monarch n : mlist)
         {
             System.out.println(mlist[i]);
             if (n.getName().compareTo(name) == 0)
             {
                 System.out.println("");  //formatting
                 return mlist[i];
                }
             else
             {
                 i++;
                }
            }
         System.out.println("");  //formatting
         return mlist[i];
    }
    
    /**
     * Searches list of Monarchs for a given name using binary search.
     * 
     * @param  mlist   list of Monarchs
     * @param  name    name of Monarch to find
     * 
     * @return mlist[i]   position of given name in the list
     */
    public static Monarch binarySearch(Monarch[] mlist, String name)
    {
         printMonarchs(mlist);
         int mid = (mlist.length - 1)/2;
         if (mlist[mid].getName().equals(name))
         {
             return mlist[mid];
         }
         else if (name.compareTo(mlist[mid].getName()) < 0)
         {
             Monarch[] list = new Monarch[mlist.length/2];
             for (int i = 0; i > mlist.length/2; i++)
             {
                 list[i] = mlist[i];
                 System.out.println(mlist[i].getName());
             }
             return binarySearch(list, name);
         }
         else if (name.compareTo(mlist[mid].getName()) > 0)
         {
             Monarch[] list = new Monarch[mlist.length/2 + 1];
             for (int i = 0; i < mlist.length/2; i++)
             {
                 list[i] = mlist[i];
                 System.out.println(mlist[i].getName());
             }
             return binarySearch(list, name);
         }
         return mlist[0];
    }
    
    /**
     * Searches list of Monarchs for a given birth year using binary search.
     * 
     * @param  mlist   list of Monarchs
     * @param  born    birthyear of Monarch to find
     * 
     * @return mlist[mid]   position of given birthyear in the list
     */
    public static Monarch binarySearch(Monarch[] mlist, int born)
    {
         int mid = (mlist.length - 1)/2;
         if (mlist[mid].getYear() == born)
         {
             return mlist[mid];
            }
            else if (born < (mid))
         {
             Monarch[] list = new Monarch[mlist.length/2];
             for (int i = 0; i < mlist.length/2 + 1; i++)
             {
                 list[i] = mlist[i];
                 System.out.println(mlist[i]);
             }
             return binarySearch(list, born);
         }
         else if (born > (mid))
         {
             Monarch[] list = new Monarch[mlist.length/2];
             for (int i = 0; i < mlist.length/2; i++)
             {
                 list[i] = mlist[i];
                 System.out.println(mlist[i]);
             }
             System.out.println(""); //formatting
             return binarySearch(list, born);
         }
         return mlist[mid];
    }
}

