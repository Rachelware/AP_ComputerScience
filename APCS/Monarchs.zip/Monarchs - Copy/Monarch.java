
/**
 * Constructs a Monarch with a name and birth year.
 * 
 * @author Rachel Ware 
 * @version 3.13.17
 */
public class Monarch
{
    private String name;
    private int year;

    /**
     * Constructor for objects of class Monarch
     */
    public Monarch(String name, int year)
    {
        this.name = name;
        this.year = year;
    }
    
    /**
     * Returns Monarch's name
     * 
     * @return name   String name
     */
    public String getName()
    {
        return name;
    }
    
    /**
     * Returns Monarch's date
     * 
     * @return date    int year
     */
    public int getYear()
    {
        return year;
    }
    
    /**
     * Returns a String of Monarch's information
     * 
     * @return String   Monarch's name and year formatted
     */
    public String toString()
    {
        return name + " ( " + year + " )";
    }
}
