import java.util.Scanner;
/**
 * Write a description of class ok here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ok
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        System.out.print("enter array size: ");
        int smallest = in.nextInt();
        int[] a = ArrayUtil1.randomIntArray(smallest, 100);
        StopWatch timer = new StopWatch();
        timer.start();
        SelectionSorter1.sort(a);
        timer.stop();
        System.out.println("Elapsed time: " + timer.getElapsedTime() + " milliseconds");
    }
}
