import java.util.Random;

/**
   This class contains utility methods for array manipulation.
*/
public class ArrayUtil2
{
   private static Random generator = new Random();

   /**
      Creates an array filled with random values.
      @param length the length of the array
      @param n the number of possible random values
      @return an array filled with length Coins with values between 0 and n - 1
   */
   public static Coin[] randomCoinArray(int length, int n)
   {
      Coin[] a = new Coin[length];
      for (int i = 0; i < a.length; i++)
      {
         a[i] = new Coin(generator.nextInt(n));
      }

      return a;
   }
   
   /**
      Swaps two entries of an array.
      @param a the array
      @param i the first position to swap
      @param j the second position to swap
   */
   public static void swap(Coin[] a, int i, int j)
   {
      Coin temp = new Coin(a[i].getValue());
      a[i] = a[j];
      a[j] = temp;
   }
}
