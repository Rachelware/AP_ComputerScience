import java.util.Scanner;
import java.util.Random;



//enter the smallest n: 10000
//enter the largest n: 100000
//Enter number of measurements: 9
/**
 * Write a description of class E14_3 here.
 * 
 * @author Rachel Ware
 * @version 3.9.17
 */
public class E14_3
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        System.out.print("enter the smallest n: ");
        int smallest = in.nextInt();
        System.out.print("enter the largest n: ");
        int largest = in.nextInt();
        System.out.print("Enter number of measurements: ");
        int number = in.nextInt();
        int change = (largest - smallest) / number;
        for (int i = largest; i >= smallest; i = i - change)
        {
            int[] a = ArrayUtil1.randomIntArray(i, 1000);
            StopWatch timer = new StopWatch();
            timer.start();
            SelectionSorter1.sort(a);
            timer.stop();
            System.out.println("Length of array: " + i + ", Elapsed time: " + timer.getElapsedTime() + " milliseconds");
       }
        }

    /**
     * Constructor for objects of class E14_3
     */
    public E14_3()
    {

    }
}
