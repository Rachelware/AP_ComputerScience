import java.util.Arrays;

/**
This program demonstrates the merge sort algorithm by
sorting an array that is filled with random numbers.
*/
public class MergeDemo
{
   public static void main(String[] args)
   {
      int[] a = ArrayUtilNew.randomIntArray(20, 3);
      System.out.println(Arrays.toString(a));

      E14_11.sort(a);

      System.out.println(Arrays.toString(a));
   }
}
