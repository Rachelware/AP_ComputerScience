import java.util.Arrays;

/**
   This program demonstrates the selection sort algorithm by
   sorting an array that is filled with random coins.
*/
public class SelectionSortDemo2
{
   public static void main(String[] args)
   {
      Coin[] a = ArrayUtil2.randomCoinArray(20, 100);
      System.out.println(Arrays.toString(a));

      SelectionSorter2.sort(a);

      System.out.println(Arrays.toString(a));
   }
}
