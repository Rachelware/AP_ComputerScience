
/**
 * Write a description of class Coin here.
 * 
 * @author Rachel Ware
 * @version 3.7.17
 */
public class Coin
{
    private int value;
    /**
     * Constructor for objects of class E14_2
     */
    public Coin(int n)
    {
        value = n;
    }

    public int getValue()
    {
       return value;
    }
    
    public String toString()
    {
        return "" + value;
    }
}
