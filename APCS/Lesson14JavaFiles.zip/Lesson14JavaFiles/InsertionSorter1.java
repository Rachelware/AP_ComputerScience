/**
   The sort method of this class sorts an array, using the selection 
   sort algorithm.
*/
public class InsertionSorter1
{
   /**
      Sorts an array, using selection sort.
      @param a the array to sort
   */
   public static void sort(int[] a)
   {  
      for (int i = 1; i < a.length; i++)
      {  
         int next = a[i];
         int j = i;
         while (j > 0 && a[j - 1] > next)
         {
             a[j] = a[j - 1];
             j--;
         }
         a[j] = next;
      }
   }

   /**
      Finds the smallest element in a tail range of the array.
      @param a the array to sort
      @param from the first position in a to compare
      @return the position of the smallest element in the
      range a[from] . . . a[a.length - 1]
   */
   private static int minimumPosition(int[] a, int from)
   {  
      int minPos = from;
      for (int i = from + 1; i < a.length; i++)
      {
         if (a[i] < a[minPos]) { minPos = i; }
      }
      return minPos;
   }
}
