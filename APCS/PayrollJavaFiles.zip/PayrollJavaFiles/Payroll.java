import java.util.ArrayList;
/**
 * Write a description of class Payroll here.
 * 
 * @author Rachel Ware
 * @version 1.20.17
 */
public class Payroll
{
    private ArrayList<Student> ary = new ArrayList<Student>();
    private ArrayList<String> output = new ArrayList<String>();
    public Payroll()
    {
        //ary.add(input);
    }
    
    public double addToPayroll(String input)
    {
        double Tax = 0;
        String name = input.split("\\s")[0];
        double wage = Double.parseDouble(input.split("\\s")[1]);
        double hours = Double.parseDouble(input.split("\\s")[2]);
        //String name = "joy";
        //double wage = 60;
        //double hours = 10;
        ary.add(new Student(name,wage,hours));
        return Tax;
    }
    
    public String createPayroll()
    {
        for (Student star : ary)
        {
            output.add(star.makePayroll());
        }
        String out = String.join("",output);
        return out;
    }

}
