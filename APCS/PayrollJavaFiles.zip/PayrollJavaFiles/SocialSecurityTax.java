
/**
 * Write a description of class Student here.
 * 
 * @author Rachel Ware
 * @version 1.20.17
 */
public class SocialSecurityTax
{
    private static String name;
    private static double wage;
    public static double hours;
    public SocialSecurityTax()
    {
        
    }
    
    public static double calculateSSTax(String input)
    {
        double Tax = 0;
        int firstSpace = 0;
        int secondSpace = 0;
        for (int i = 0; i < input.length(); i++)
        {
            if (input.substring(i, i + 1).equals(" "))
            {
                secondSpace = i;
            }
        }
        for (int i = 0; i < secondSpace; i++)
        {
            if (input.substring(i, i + 1).equals(" "))
            {
                firstSpace = i;
            }
        }
        name = input.substring(0, firstSpace);
        wage = Double.parseDouble(input.substring(firstSpace, secondSpace));
        hours = Double.parseDouble(input.substring(secondSpace, input.length() - 1));
        System.out.println(firstSpace);
        System.out.println(secondSpace);
        System.out.println(name);
        System.out.println(wage);
        System.out.println(hours);
        return Tax;
    }
}
