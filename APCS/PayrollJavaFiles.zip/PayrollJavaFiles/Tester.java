import java.util.Scanner;

/**
 * Write a description of class Tester here.
 * 
 * @author Rachel Ware
 * @version 1.23.17
 */
public class Tester
{
    public static void main(String[] args)
    {
        Payroll pay = new Payroll();
        Scanner in = new Scanner(System.in);
        System.out.println("input a student name followed by wage and hours, separated by space. \nEnter -1 at any time to stop: ");
        String input = in.nextLine();
        while (!input.equals("-1"))
        {
            pay.addToPayroll(input);
            input = in.nextLine();
        }
        System.out.print(pay.createPayroll());
    }
}
