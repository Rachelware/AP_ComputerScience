
/**
 * Write a description of class Student here.
 * 
 * @author Rachel Ware
 * @version 1.20.17
 */
public class Student
{
    private String name = " ";
    private double wage;
    private double hours;
    private double income;
    private double fedTax;
    private double SSTax;
    private double checkAmount;
    public Student(String name, double wage, double hours)
    {
        this.name = name;
        this.wage = wage;
        this.hours = hours;
    }
    
    public String makePayroll()
    {
        income = wage * hours;
        if (income <= 118500)
        {
             SSTax = income * .0765;
        }
        else //if (income > 118500)
        {
            SSTax = 118500 * .0765;
        }
        if (income <= 32000)
        {
            fedTax = income * .1;
        }
        else //if (income > 32000)
        {
            fedTax = (32000 * .1) + ((income - 32000) * .25);
        }
        checkAmount = income - SSTax - fedTax;
        //DecimalFormat formatter = new DecimalFormat("#.00");
        //income = formatter.format(income);
        
        String payroll = "\nIncome for " + name + ": " + income + "\nSocial Security Tax for " + name + ": " + SSTax + "\nFederal Tax for " + name + ": " + fedTax + "\nCheck amount for " + name + ": " + checkAmount + "\n";
        return payroll;
    }
}
