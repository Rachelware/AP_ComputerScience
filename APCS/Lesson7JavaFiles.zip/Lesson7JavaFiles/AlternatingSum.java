/**
 * Write a description of class E7_6 here.
 * Exercise E7.6
 * 
 * @author Rachel Ware
 * @version 11.17.16
 */
public class AlternatingSum
{
    public static void main (String[] args)
    {
       double[] data = { 1, 4, 9, 16, 9, 7, 4, 9, 11 };
       E7_6 util = new E7_6();
       double total = util.alternatingSum(data);
       System.out.println("Expected sum:  -2");
       System.out.println("Alternating sum: " + total);
    }
    
    public double alternatingSum(double [] values)
    {
        double sum =0;
        for (int i = 0; i < values.length; i++)
        {
            
            if ( i % 2 == 1)
            {
                sum = sum - values[i];
            }
            else
            {
                sum = sum + values[i];
            }
            System.out.println( sum);
        }
        return sum;
    }
}
