import java.util.Random;
/**
 * Write a description of class E7_1 here.
 * 
 * @author Rachel Ware
 * @version 11.16.16
 */
public class E7_1
{
    public static void main (String[] args)
    {
        int[] values = new int[10];
        Random rand = new Random();
        for (int i = 0; i < values.length; i++)
        {
            values[i] = rand.nextInt(101);
        }
        System.out.println("Original array: "); 
        for (int element : values)
        {
                System.out.print(element + ", ");
        }
        System.out.println(" ");
        System.out.println("Every element at even index: ");
        for (int i = 0; i < values.length - 1; i++)
        {
            if (i% 2 == 0)
            {
                int element = values[i];
                System.out.print(element + ", ");
            }
        }
        System.out.println("");
        System.out.println("Every even element: ");
        for (int element : values)
        {
            if (element % 2 == 0)
            {
                System.out.print(element + ", ");
            }
        }
        System.out.println("");
        System.out.println("Elements reversed: ");
        for (int i = values.length -1; i > -1; i--)
        {
            int element = values[i];
            System.out.print(element + ", ");
        }
        System.out.println("");
        System.out.println("First and last elements: ");
        System.out.print(values[0] + ", ");
        System.out.println(values[values.length -1]);
    }
}

