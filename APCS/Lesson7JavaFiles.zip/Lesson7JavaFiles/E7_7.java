
/**
 * Write a description of class E7_7 here.
 * 
 * @author Rachel Ware
 * @version 11.17.16
 */
public class E7_7
{
    public static void main(String[] args)
    {
        double [] values = {1,4,9,16,9,7,4,9,11};
        E7_7 fun = new E7_7();
        fun.reverse(values);
    }
    
    public double reverse(double [] values)
    {
        double temp = 0;
        for (int i = 0; i < values.length/2; i++)
        {
            temp = values[i];
            values[i] = values[values.length -1 - i];
            values[values.length - 1 - i] = temp;
        }
        for (double element : values)
        {
            System.out.print(element + ", ");
        }
        return temp;
    }
}


