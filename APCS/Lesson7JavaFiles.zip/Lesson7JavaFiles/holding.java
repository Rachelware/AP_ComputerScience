
public class holding //E7_1
{
    public static void main (String[] args)
    {
        int[] values = new int[10];
        Random rand = new Random();
        for (int element : values)
        {
            element = rand.nextInt(100) + 1;
        }
        System.out.println(values);
        System.out.println(" Every Element at an even index: ");
        for (int i = 0; i < values.length - 1; i++)
        {
            if (i% 2 == 1)
            {
                System.out.print(values[i] + ", ");
            }
        }
        System.out.println("");
        System.out.println("Every even element: ");
        for (int element : values)
        {
            if (element % 2 == 1)
            {
                System.out.print(element + ", ");
            }
        }
        System.out.println("");
        System.out.println("In reverse order: ");
        for (int i = values.length -1; i > -1; i--)
        {
            System.out.print(values[i] + ", ");
        }
        System.out.println("");
        System.out.println("First and last Element: ");
        System.out.print(values[0]);
        System.out.println(values[values.length -1]);
    }
}

public class holding //AlternatingSum
{
    public double alternatingSum(double [] sequence)
    {
        double sum = 0;
        for (int i = 0; i < sequence.length -1; i++)
        {
            if (i % 2 == 1)
            {
                sum = sum + sequence[i];
            }
            else
            {
                sum = sum - sequence[i];
            }
        }
        return sum;
    }
    
    public static void main (String[] args)
    {
        double[] data = { 1,4,9,16,9,7,4,9,11 };
        AlternatingSum util = new AlternatingSum();
        double total = util.alternatingSum(data);
        System.out.println("Expected sum: -2");
        System.out.println("Alternating sum: " + total);
    
    }
    
}
