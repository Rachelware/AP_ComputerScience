import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.IOException;
/**
 * Roach population
 * 
 * @author Rachel Ware
 * @version 2.7.17
 */
public class frame implements ActionListener
{
    public static void main(String[] args)
    {
     /** javax.swing.SwingUtilities.invokeLater(new Runnable()
      {
          public void run() 
          {
               createAndShowGUI();
            }
        });
      try
      {
          Toolkit t = Toolkit.getDefaultToolkit();
          Image img = t.getImage("image.png");
          
        }
      catch ()
      {
          
        } try
       
     * {
          Toolkit t = Toolkit.getDefaultToolkit();
          Image img = t.getImage("image.png");
          
       }
      catch (IOException ex)
      {
          System.out.print("error");
        } */
    }  
    
    private void createAndShowGUI()
    {
        JFrame frame = new JFrame("Roaches");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JButton button = new JButton("clickbait");
        button.setSize(80,30);
        frame.add(button);
        button.addActionListener(this);
        JLabel label = new JLabel("roaches");
        label.setPreferredSize(new Dimension(175,100));
        frame.getContentPane().add(label, BorderLayout.CENTER);
        frame.pack();
        frame.setVisible(true);
        label.setVisible(true);
        button.setVisible(true);
    }
    
    public void actionPerformed(ActionEvent event)
    {
      
    }
    }
